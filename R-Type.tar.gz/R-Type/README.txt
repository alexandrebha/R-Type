Mon jeu est nommé R-type, dans ce jeu je dois contrôler un vaisseau de gauche à droite et
de bas en haut, qui tire des boules de feu, afin de détruire des vaisseaux ennemis qui arrivent pas la
droite.
Les touches par défaut de mon jeu sont les touches directionnelles, mais on peut les changer dans
« CONTROLS», que l'on retrouve dans les paramètres.
Par ailleurs mon jeu est totalement en anglais .
Le jeu est composé de la manière suivante ; lorsqu'on compile le programme, on arrive dans un
menu, à partir de ce menu, on peut soit cliquer sur « SETTINGS » soit cliquer sur « START » , dans
« SETTINGS » on peut changer la difficulté du jeu, le mode de jeu « gamemode » et les
commandes, en cliquant sut « START » on peut commencer directement à jouer avec les paramètres
de base qui sont:
-une difficulté simple ;
-un mode de jeu (gamemode) normal qui correspond à une
version de R-type de base ;
-les touches directionnelles pour déplacer le vaisseau et la
touche espace pour tirer des boules de feu ;
Ce que l'on peut retrouver en allant dans « SETTINGS » :
-Des niveau de difficulté : « EASY », « NORMAL » et « HARD ».
-Deux modes de jeu : « NORMAL MODE » et « DRAGON BALL MODE ».
-Des commande : « touches directionnelles » et « zqsd » pour déplacer le vaisseau.
Pour fermer le jeu il faut cliquer sur « exit game » qui est tout le temps placée en bas à droite de la
fenêtre.
