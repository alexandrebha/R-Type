#include <stdlib.h>
#include <stdio.h>
#include <libTableauNoir.h>
#include <math.h>
typedef struct{
	double x;
	double y;
	int pf;
	int az;
	int za;
	int bouge;
	int abc;
	
}Objet;
/*appels des fonction */

	Objet deplacementvaisseau (EtatSourisClavier esc, int p, Objet vaisseau, Image vaisseaudroit, Image vaisseauhaut, Image vaisseaubas, int haut, int bas, int droite, int gauche);
	int afficherbdf( int i, Objet bouledefeu[], Image fire, EtatSourisClavier esc, Objet vaisseau);
	int ennemis(Objet ennemi[], Image vaisseaudroit, int B, int niveau);
	double distance(double x1, double y1, double x2, double y2);
	int fond(int pj, Image p1, Image p2, Image p3,Image p4,Image p5,Image p6,Image p7,Image p8,Image p9,Image p10,Image p11,Image p12,Image p13,Image p14,Image p15,Image p16,Image p17,Image p18,Image p19,Image p20,Image p21,Image p22,Image p23,Image p24);
	int fond2(int jp, Image jp1);
	
	
	int collisions(Objet vaisseau,Objet bouledefeu[], Objet ennemi[], int page);
	void rectangle(int x1, int y1, int x2, int y2);
	Objet planbouge(Objet mouvement);
	Objet bougerplan(Objet planquibouge, Image space, Image space1);
	



int main(){
	creerTableau();
	fixerTaille(800, 500 );
	
	choisirCouleurFond(0, 30, 45 );
	Objet vaisseau; 
	Objet mouvement;
	Objet planquibouge;
	
	vaisseau.x = -385;
	vaisseau.y = 0;
	mouvement.bouge = 400;
	mouvement.abc = 600;
	planquibouge.az = -400;
	planquibouge.za = 400;
	
	
	
	Objet bouledefeu[10];
	
				/*--positions des boules de feux initialisées en y=500 car elles se remettent en (0,0) ce qui est problématique-------*/
	bouledefeu[0].y = 500; bouledefeu[1].y = 500; bouledefeu[2].y = 500; bouledefeu[3].y = 500; bouledefeu[4].y = 500; bouledefeu[5].y = 500; bouledefeu[6].y = 500; bouledefeu[7].y = 500; bouledefeu[8].y = 500; bouledefeu[9].y = 500;
	
				/*---on a 10 ennemis qui se relayent---*/
	Objet ennemi[10];
	
	int f =0;   		  /*f sert a fermer le programme si il est egal a 1*/
	int pj = 0;			/*pj permet denchainer les differentes images du menu afin de donner la sensation dune video*/
	
	
	
	
				/*images du jeu en lui meme*/
	Image vaisseaudroit = chargerImage("vaisseaudroit.png");
	Image vaisseauhaut = chargerImage("vaisseauhaut.png");  /*-----------droit, haut et bas representent les formes que doit prendre le vaissseau en cas de mouvement --------------------*/
	Image vaisseaubas = chargerImage("vaisseaubas.png");
	Image space = chargerImage("fd.png");			// space est l'image du fond du jeu
	Image fire = chargerImage("fire.png");  		// fire représente la boule de feu que le vaisseau tire sur l'ennemi
	Image goku = chargerImage("ennemis.png");		// goku représente l'ennemi (en référance) au mode de jeu dragon ball quon peut retrouver dans "gamemode"
	Image space1 = chargerImage("fd.png");
	
				/*-----images des parametres---------------*/
	Image p1 = chargerImage("frame-01.gif");
	Image p2 = chargerImage("frame-02.gif");
	Image p3 = chargerImage("frame-03.gif");
	Image p4 = chargerImage("frame-04.gif");
	Image p5 = chargerImage("frame-05.gif");
	Image p6 = chargerImage("frame-06.gif");
	Image p7 = chargerImage("frame-07.gif");
	Image p8 = chargerImage("frame-08.gif");
	Image p9 = chargerImage("frame-09.gif");
	Image p10 = chargerImage("frame-10.gif");
	Image p11 = chargerImage("frame-11.gif");
	Image p12 = chargerImage("frame-12.gif");
	Image p13 = chargerImage("frame-13.gif");
	Image p14 = chargerImage("frame-14.gif");
	Image p15 = chargerImage("frame-15.gif");
	Image p16 = chargerImage("frame-16.gif");
	Image p17 = chargerImage("frame-17.gif");
	Image p18 = chargerImage("frame-18.gif");
	Image p19 = chargerImage("frame-19.gif");
	Image p20 = chargerImage("frame-20.gif");
	Image p21 = chargerImage("frame-21.gif");
	Image p22 = chargerImage("frame-22.gif");
	Image p23 = chargerImage("frame-23.gif");
	Image p24 = chargerImage("frame-24.gif");  /*--------------p1 à p24 représentent les images du menu qui donnent la sensation d'une vidéo-----------------*/
	Image titre = chargerImage("TYPE.png");		/*-----------titre est le "R-TYPE" du menu--------------*/
	Image settings = chargerImage("settings.png");
	Image start = chargerImage("start.png");
	Image choix = chargerImage("choixdif.png");
	Image easy = chargerImage("easy.png");
	Image normal = chargerImage("normal.png");
	Image hard = chargerImage("hard.png");
	Image gameover = chargerImage("GAMEOVER.png");
	Image spacebar = chargerImage("spacebar.png");
	Image retoursettings = chargerImage("retoursettings.png");
	Image dragon = chargerImage("dragon.png");
	Image ballmode = chargerImage("ballmode.png");
	Image normalmode = chargerImage("normalmode.png");
	Image select = chargerImage("select.png");
	Image restart = chargerImage("restart.png");
	Image freezer = chargerImage("freezermen.png");
	Image alien = chargerImage("alienmenu.png");
	Image alyen = chargerImage("alienmenu1.png");
	Image exit = chargerImage("exitegame.png");
	Image moveship = chargerImage("moveship.png");
	Image retour = chargerImage("retour.png");
	Image zqsd = chargerImage("zqsd.png");
	Image touches_directions = chargerImage("directions.png");
	Image dif = chargerImage("diff.png");
	Image controls = chargerImage("controls.png");
	Image gamemode = chargerImage("gamemode.png");
	Image use = chargerImage("use.png");
	Image toshoot = chargerImage("toshoot.png");
	Image barspace = chargerImage("barspace.png");
				
	
	int page = 0;  /*page est une varible qui peut prend pour valeur 0,1,2,3,4,5 ou 10
					0 permet louverture du menu,
					1 permet louverture du jeu (bouton START)
					2 permet louverture des parametres (bouton SETTINGS)
					3 permet l'ouverture de "difficulty" qui permet de changer la difficulté du jeu
					4 permet l'ouverture de "gamemode"
					5 permet l'ouverture de "controls" qui permet de changer les commandes de jeu
					10 permet l'ouverture de la page "GAME OVER" du jeu
					*/
	int niveau = 4;		/*--------------niveau peut prendre pour valeur 4, 6 ou 8 elle permet d'augmenter la vitesse des ennemis---------------*/
	int compteur = 0;
	int haut = 82; /*----haut,bas, droite et gauche sont des variables qui permettent de changer les commandes dans "controls"--------------*/
	int bas = 81;
	int droite = 79;
	int gauche = 80;

	fixerModeBufferisation(1);
	
				/*--------------------------(while(f==0)) gere l'entièreté du jeu-----------------*/
	while(f==0){
			compteur++;
			
					/*------------si page est égal a 0 on rentre dans le menu (page est initialisé à 0-----------------*/
		if(page == 0){
			effacerTableau();
			
			EtatSourisClavier esc=lireEtatSourisClavier();
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				printf("cest fini\n");
				return EXIT_SUCCESS;
			}
			
			
		
			pj = fond(pj, p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23,p24);
		
		
			afficherImage(titre, 0 - tn_largeur(titre)/2, 150 + tn_hauteur(titre)/2);
			afficherImage(settings, -170 - tn_largeur(settings)/2, 0 + tn_hauteur(settings)/2);
			afficherImage(start, 200 - tn_largeur(start)/2, 0 + tn_hauteur(start)/2);
			
			afficherImage(alien, 251, 250);
			afficherImage(alyen, -400, 250);		/*---------éléments de décoration dans le menu---------*/
			
			
			afficherImage(exit, 250, -220);
			
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(240,-215,377,-247);
			}
			else{
				choisirTypeStylo(5,100, 100, 100);
				rectangle(240,-215,377,-247);
			}
			
		
		
		
		

			/*-----------------page devient prend la valeur 1 si on clique sur le bouton "START" du menu, cela premet de rentrer dans la boucle if(abc==1) qui nous fait rentrer dans le jeu------------*/
			if(esc.sourisX>90 && esc.sourisX<310 && esc.sourisY>-38 && esc.sourisY<38 && esc.sourisBoutonGauche ==1){
			page = 1;}
			
			/*-----------------page devient prend la valeur 2 si on clique sur le bouton "SETTINGS" du menu, cela premet de rentrer dans la boucle if(abc==2) qui nous fait rentrer dans lS PARAMETRES DU JEU------------*/
			
			if(esc.sourisX>-325 && esc.sourisX<-15 && esc.sourisY>-38 && esc.sourisY<38 &&  esc.sourisBoutonGauche ==1){
				page =2;
			}
			
			
			
			
				
			/*--------------les quatres prochaines boucles "if" gerent la mise en surbrilance des boutons START et SETTINGS-------------------------*/
			if(esc.sourisX>90 && esc.sourisX<310 && esc.sourisY>-38 && esc.sourisY<38 ){
				
				choisirTypeStylo(8, 0, 250, 0);
				rectangle(90,38,310,-38);
				choisirTypeStylo(5, 50, 205, 50);
			}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(90,38,310,-38);
			}
			
			if(esc.sourisX>-325 && esc.sourisX<-15 && esc.sourisY>-38 && esc.sourisY<38){
				choisirTypeStylo(8, 0, 250, 0);
				rectangle(-325,38,-15,-38);
				choisirTypeStylo(5, 50, 205, 50);
			}		
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-325,38,-15,-38);
				
			}

			tamponner();
		
	
	}			 /*fin de la boucle "if(page ==0)"   */
	
	
	
	
		int p = 0; /*p gere laffichage du vaisseau selon sa direction (montante, descendante etc...*/
		int i = 0; /*i gère laffichage des bouledefeu qui servent à detruire les ennemis*/
		int B = 0;
		int m;
	
		for(m = 0; m<10; m++){
			ennemi[m].pf = 0;			/*--------cette boucle for permet d'initialiser tout les ennemis en dehor de la fenettre de jeu, ennemi[m].pf=0 signifie que l'ennemi n'est plus dans la fenetre de jeu---------------*/
		}
	
	
		
		if(page ==1){
				/*-----------cette boucle correspond au jeu même-----------*/
		while(-250<=vaisseau.y && vaisseau.y<=250 && -400<=vaisseau.x && vaisseau.x<=400 && f==0 && page ==1){
			EtatSourisClavier esc=lireEtatSourisClavier();
		
			B = B + 1;
		
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				return EXIT_SUCCESS;
			}
			effacerTableau();
			
			//fonction utilisées dans le jeu
			planquibouge = bougerplan(planquibouge, space, space1);
			vaisseau = deplacementvaisseau(esc, p, vaisseau, vaisseaudroit, vaisseauhaut, vaisseaubas, haut, bas, droite, gauche);
			i = afficherbdf( i, bouledefeu, fire, esc, vaisseau);
			niveau = ennemis(ennemi, goku, B, niveau);
			choisirTypeStylo(5, 152, 255, 152);
			mouvement = planbouge(mouvement);
			page = collisions(vaisseau, bouledefeu, ennemi, page);
			
			/*------images exit, retour menu---------*/
			afficherImage(exit, 250, -220);
			afficherImage(retour, -270 - tn_largeur(retour)/2, -210 + tn_hauteur(retour)/2);
			
			
			/*---------surbrillance "exit"--------------*/
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(240,-215,377,-247);
			}
			else{
				choisirTypeStylo(5,100, 100, 100);
				rectangle(240,-215,377,-247);
			}
			
			/*--------------"surbrillance" return menu---------------*/
			if(esc.sourisX>-375 && esc.sourisX<-165 && esc.sourisY>-224 && esc.sourisY<-196){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-375,-224,-165,-196);
				
				
			}		
			else{choisirTypeStylo(5, 100, 100, 100);
				rectangle(-375,-224,-165,-196);
			}
			
			/*-------------si on clique sur "return menu" alors page=0 (page =0) correspond a la page du menu---------------*/
			if(esc.sourisX>-375 && esc.sourisX<-165 && esc.sourisY>-224 && esc.sourisY<-196 && esc.sourisBoutonGauche ==1){
				page = 0;
				vaisseau.x = -390;		/*-----les position du vaisseau est remise en (-390,0) pour faire recommencer le jeu-------------*/
				vaisseau.y = 0;
			}
	
		tamponner();
		
	
	}
	}
	
	if(page ==2){
		
		effacerTableau();
		
			EtatSourisClavier esc=lireEtatSourisClavier();
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				printf("cest fini\n");
				return EXIT_SUCCESS;
			}
			
			
		
			pj = fond(pj, p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23,p24);
			
			/*---------------differentes images affichées---------------*/
			afficherImage(retour, -270 - tn_largeur(retour)/2, -210 + tn_hauteur(retour)/2);
			afficherImage(settings, 0 - tn_largeur(settings)/2, 200 + tn_hauteur(settings)/2);
			afficherImage(dif, -250 - tn_largeur(dif)/2, 80 + tn_hauteur(dif)/2);
			afficherImage(gamemode, 210 - tn_largeur(gamemode)/2, 80 + tn_hauteur(gamemode)/2);
			afficherImage(controls, 0 - tn_largeur(controls)/2, -100 + tn_hauteur(controls)/2);
			afficherImage(exit, 250, -220);
			
			/*--------------surbrillance----------------*/
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(240,-215,377,-245);
			}
		else{
				choisirTypeStylo(5,100, 100, 100);
				rectangle(240,-215,377,-245);
			}
			
			
			/*----------surbrillance retourner au menu-------------*/
			if(esc.sourisX>-375 && esc.sourisX<-165 && esc.sourisY>-224 && esc.sourisY<-196){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-375,-224,-165,-196);
			}
			else{choisirTypeStylo(5, 100, 100, 100);
				rectangle(-375,-224,-165,-196);
				}
				
			if(esc.sourisX>-375 && esc.sourisX<-165 && esc.sourisY>-224 && esc.sourisY<-196 && esc.sourisBoutonGauche ==1){
				page = 0;
			}
			/*----------surbrillance difficulté--------------->*/
			if(esc.sourisX>-390 && esc.sourisX<-110 && esc.sourisY>51 && esc.sourisY<109){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-390,109,-110,51);
				
				
			}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-390,109,-110,51);
				}
			
			
			/*---------------surbrillance gamemode-----------------*/
			
			if(esc.sourisX>50 && esc.sourisX<370 && esc.sourisY>50 && esc.sourisY<109){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(50,50,370,109);
			}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(50,50,370,109);
			}
			
			
			
			/*---------------surbrillance controls-----------------*/
			
			if(esc.sourisX>-133 && esc.sourisX<133 && esc.sourisY>-129 && esc.sourisY<-71){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-133,-71,133,-129);
			}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-133,-71,133,-129);
			}
			/*------------aller a la difficulté-----------*/
			
			if(esc.sourisX>-390 && esc.sourisX<-110 && esc.sourisY>51 && esc.sourisY<109 && esc.sourisBoutonGauche ==1){
				page = 3;
			}
			
			/*------------aller au gamemode--------------*/
			if(esc.sourisX>50 && esc.sourisX<370 && esc.sourisY>50 && esc.sourisY<109 && esc.sourisBoutonGauche ==1){
				page = 4;
			}
			
			/*------------aller aux controls--------------*/
			if(esc.sourisX>-133 && esc.sourisX<133 && esc.sourisY>-129 && esc.sourisY<-71 && esc.sourisBoutonGauche ==1){
				page = 5;
			}
			
			
			
			
		tamponner();
		
				}// fin de la boucle if(page==2)
	
	
	
	if(page==3){
					/*--------------on rentre dans "DIFFICULTY"---------------------*/
		effacerTableau();
			
			EtatSourisClavier esc=lireEtatSourisClavier();
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				printf("cest fini\n");
				return EXIT_SUCCESS;
			}
			
			/*----------------Images affichées---------------*/
			pj = fond(pj, p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23,p24);
			afficherImage(retoursettings, -260 - tn_largeur(retoursettings)/2, -170 + tn_hauteur(retoursettings)/2); /*-210*/
			afficherImage(choix, 0 - tn_largeur(choix)/2, 200 + tn_hauteur(choix)/2);
			afficherImage(easy,  -190 - tn_largeur(easy)/2, 60 + tn_hauteur(easy)/2);
			afficherImage(normal,  190 - tn_largeur(normal)/2, 60 + tn_hauteur(normal)/2);
			afficherImage(hard, 0 - tn_largeur(hard)/2, -100 + tn_hauteur(hard)/2);
			afficherImage(exit, 250, -220);
			
			/*-----------------surbrillance exit-----------------*/
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(240,-215,377,-245);
			}
			else{
				choisirTypeStylo(5,100, 100, 100);
				rectangle(240,-215,377,-245);
			}
			
			/*----------surbrillance "return to settings"-------------*/
			if(esc.sourisX>-400 && esc.sourisX<-120 && esc.sourisY>-187 && esc.sourisY<-153){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-400,-187,-120,-153);
				}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-400,-187,-120,-153);
				}
			
			/*----------------les settings correspondent à la page = 2--------------*/
			if(esc.sourisX>-400 && esc.sourisX<-120 && esc.sourisY>-187 && esc.sourisY<-153 && esc.sourisBoutonGauche ==1){
				page = 2;
			}
			
			/*-----------surbrillance easy-----------------*/
			
			
			if(esc.sourisX>-258 && esc.sourisX<-122 && esc.sourisY>32 && esc.sourisY<88  ){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-258,32,-122,88);
				}
			
			else{
				choisirTypeStylo(4, 128, 128, 128);	
				if(niveau==4){
					choisirTypeStylo(4, 50, 205, 50);
							}
				
				rectangle(-258,32,-122,88);
				
			}
			
			/*---------------surbrillance normal---------------*/
			
			if(esc.sourisX>80 && esc.sourisX<300 && esc.sourisY>32 && esc.sourisY<88){
				
				choisirTypeStylo(4, 255, 128, 0);
				rectangle(75,88,305,32);
				}
			else{
					choisirTypeStylo(4, 128, 128, 128);
				if(niveau==6){choisirTypeStylo(4, 255, 128, 0);}
				
				rectangle(75,88,305,32);
				
			}
			
			/*-----------------surbrillance hard------------------*/
			if(esc.sourisX>-75 && esc.sourisX<75 && esc.sourisY>-128 && esc.sourisY<-72){
				
				choisirTypeStylo(4, 254, 27, 50);
				rectangle(-75,-72,75,-128);
				}
		
				else{
					choisirTypeStylo(4, 128, 128, 128);
				if(niveau==8){choisirTypeStylo(4, 254, 27, 50);}
				
				rectangle(-75,-72,75,-128);
				
			}
			
			/*--------------niveau = 4: easy----------------*/
			if(esc.sourisX>-258 && esc.sourisX<-122 && esc.sourisY>32 && esc.sourisY<88 && esc.sourisBoutonGauche ==1){
				niveau = 4;
				
			}
			/*--------------niveau = 6: normal------------*/
			if(esc.sourisX>80 && esc.sourisX<300 && esc.sourisY>32 && esc.sourisY<88 && esc.sourisBoutonGauche ==1){
				niveau = 6;
				
			}
			/*--------------niveau = 8: hard---------*/
			if(esc.sourisX>-75 && esc.sourisX<75 && esc.sourisY>-128 && esc.sourisY<-72 && esc.sourisBoutonGauche ==1){
				niveau = 8;
				
			}
			
		tamponner();
				}// fin de la boucle (if(page==3))
				
				
				
				
	if(page ==4){
			
			
			
			effacerTableau();
			EtatSourisClavier esc=lireEtatSourisClavier();
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				printf("cest fini\n");
				return EXIT_SUCCESS;
			}
			
			pj = fond(pj, p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23,p24);
			afficherImage(retoursettings, -260 - tn_largeur(retoursettings)/2, -170 + tn_hauteur(retoursettings)/2);
			afficherImage(select, 0 - tn_largeur(select)/2, 150 + tn_hauteur(select)/2);
			afficherImage(dragon,  -160 - tn_largeur(dragon)/2, 30 + tn_hauteur(dragon)/2);
			afficherImage(ballmode,  70 - tn_largeur(ballmode)/2, 30 + tn_hauteur(ballmode)/2);
			afficherImage(normalmode,  -32 - tn_largeur(normalmode)/2, -70 + tn_hauteur(normalmode)/2);
			afficherImage(exit, 250, -220);
			
			
			
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(240,-215,377,-247);
				}
			else{
				choisirTypeStylo(5,100, 100, 100);
				rectangle(240,-215,377,-247);
			}
			
			/*----------surbrillance retourner au settings-------------*/
			if(esc.sourisX>-400 && esc.sourisX<-120 && esc.sourisY>-187 && esc.sourisY<-153){			
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-400,-187,-120,-153);
				}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-400,-187,-120,-153);
			}
			if(esc.sourisX>-400 && esc.sourisX<-120 && esc.sourisY>-187 && esc.sourisY<-153 && esc.sourisBoutonGauche ==1){
				page = 2;
			}
			
			/*------------surbrillance dragonballmode-----------------------*/
			
			if(esc.sourisX>-255 && esc.sourisX<225 && esc.sourisY>0 && esc.sourisY<60){
				
				choisirTypeStylo(4, 247, 255, 60);
				rectangle(-270,60,225,0);
				} 
			else{
					choisirTypeStylo(5, 100, 100, 100);
					rectangle(-270,60,225,0);
			}
			if(esc.sourisX>-255 && esc.sourisX<225 && esc.sourisY>0 && esc.sourisY<60 && esc.sourisBoutonGauche ==1){
				space = chargerImage("namek.png");
				space1 = chargerImage("namekk.png");
				vaisseaudroit = chargerImage("freezerdroit.png");
				vaisseauhaut = chargerImage("freezerhaut.png");  /*-----------droit, haut et bas representent les formes que doit prendre le vaissseau en cas de mouvement --------------------*/
				vaisseaubas = chargerImage("freezerbas.png");
				fire = chargerImage("attaque.png");
				goku = chargerImage("gku.png");			/*images du menu*/
				titre = chargerImage("TYPE1.png");
				settings = chargerImage("settings1.png");
				start = chargerImage("start1.png");
				choix = chargerImage("choixdif1.png");
				easy = chargerImage("easy1.png");
				normal = chargerImage("normal1.png");
				hard = chargerImage("hard2.png");
				gameover = chargerImage("GAMEOVER1.png");
				spacebar = chargerImage("spacebar1.png");
				retoursettings = chargerImage("retoursettings1.png");
				select = chargerImage("select1.png");
				/*images des parametres*/
							
				retour = chargerImage("retour1.png");//*
				dif = chargerImage("diff1.png");
				controls = chargerImage("controls1.png");
				gamemode = chargerImage("gamemode1.png");
							
						}
				
				/*-----------------------------surbrillance normal mode-----------------------------------*/
			if(esc.sourisX>-232 && esc.sourisX<168 && esc.sourisY>-98 && esc.sourisY<-42){
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-242,-98,178,-42);
				}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-242,-98,178,-42);
				}
			
			if(esc.sourisX>-232 && esc.sourisX<168 && esc.sourisY>-98 && esc.sourisY<-42 && esc.sourisBoutonGauche ==1){
					vaisseaudroit = chargerImage("vaisseaudroit.png");
					vaisseauhaut = chargerImage("vaisseauhaut.png");  /*-----------vaisseaudroit, vaisseauhaut et vaisseaubas representent les formes que doit prendre le vaissseau en cas de mouvement --------------------*/
					vaisseaubas = chargerImage("vaisseaubas.png");
					space1 = chargerImage("fd.png");
					space = chargerImage("fd.png");
					 fire = chargerImage("fire.png");
					 goku = chargerImage("ennemis.png");
					 titre = chargerImage("TYPE.png");
					 settings = chargerImage("settings.png");
					 start = chargerImage("start.png");
					 choix = chargerImage("choixdif.png");
					easy = chargerImage("easy.png");
					normal = chargerImage("normal.png");
					 hard = chargerImage("hard.png");
					 gameover = chargerImage("GAMEOVER.png");
					 spacebar = chargerImage("spacebar.png");
					 retoursettings = chargerImage("retoursettings.png");
					 dragon = chargerImage("dragon.png");
					 ballmode = chargerImage("ballmode.png");
					 normalmode = chargerImage("normalmode.png");
					 select = chargerImage("select.png");
					 retour = chargerImage("retour.png");
					 dif = chargerImage("diff.png");
					 controls = chargerImage("controls.png");
					 gamemode = chargerImage("gamemode.png");
				
			}
			
		tamponner();}// fin de la boucle if(page==4)


		if(page==5){
			//cette boucle sert a choisir ses touches , la page égale à 5 correspond à la page "CONTROLS"
			effacerTableau();
			
			EtatSourisClavier esc=lireEtatSourisClavier();
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				printf("cest fini\n");
				return EXIT_SUCCESS;
			}
			pj = fond(pj, p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23,p24);
			afficherImage(exit, 250, -220);
			afficherImage(retoursettings, -260 - tn_largeur(retoursettings)/2, -170 + tn_hauteur(retoursettings)/2);
			afficherImage(controls, 40 - tn_largeur(gamemode)/2, 200 + tn_hauteur(gamemode)/2);
			afficherImage(zqsd, -200 - tn_largeur(zqsd)/2, 50 + tn_hauteur(zqsd)/2);
			afficherImage(touches_directions, 100 - tn_largeur(touches_directions)/2, 50 + tn_hauteur(touches_directions)/2);
			afficherImage(use, -300, -100);
			afficherImage(barspace, -230, -80);
			afficherImage(toshoot, -30, -93);
			
			/*------------surbrillance zqsd---------------*/
			if(esc.sourisX>-295 && esc.sourisX<-105 && esc.sourisY>0 && esc.sourisY<100){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-295,100,-105,0);
				}
			else{
					choisirTypeStylo(5, 100, 100, 100);
				if(haut==26){choisirTypeStylo(4, 50, 205, 50);}
				rectangle(-295,100,-105,0);
			}
			/*--------------si on clique sur la "case" zqsd les variables haut,bas,droite et gauche prennent des valeurs correspondant aux touches zqsd--------------*/
				if(esc.sourisX>-295 && esc.sourisX<-105 && esc.sourisY>0 && esc.sourisY<100 && esc.sourisBoutonGauche ==1){
					haut = 26;
					bas =22;
					droite =7;
					gauche =4;
				}
				/*----------------- fin surbrillance zqsd-------------------*/
				
				
				/*----------------subrillance touches directionneles----------------*/
				
				
				if(esc.sourisX>5 && esc.sourisX<195 && esc.sourisY>0 && esc.sourisY<100){
				
					choisirTypeStylo(4, 50, 205, 50);
					rectangle(5,100,195,0);
				}
				else{
					choisirTypeStylo(5, 100, 100, 100);
				if(haut==82){choisirTypeStylo(4, 50, 205, 50);}
					rectangle(5,100,195,0);
				}
				/*--------------si on clique sur la "case" des flèches directionnelles, les variables haut,bas,droite et gauche prennent des valeurs correspondant à ces touches--------------*/
				
				if(esc.sourisX>5 && esc.sourisX<195 && esc.sourisY>0 && esc.sourisY<100 && esc.sourisBoutonGauche ==1){
					haut = 82;
					bas = 81;
					droite =79;
					gauche =80;
				}
				
				
				/*------------fin surbrillance touches directionelles-----------*/
			
				if(esc.sourisX>-400 && esc.sourisX<-120 && esc.sourisY>-187 && esc.sourisY<-153){
				
					choisirTypeStylo(4, 50, 205, 50);
					rectangle(-400,-187,-120,-153);
				}
				else{
					choisirTypeStylo(5, 100, 100, 100);
					rectangle(-400,-187,-120,-153);
				}
			
			
				if(esc.sourisX>-400 && esc.sourisX<-120 && esc.sourisY>-187 && esc.sourisY<-153 && esc.sourisBoutonGauche ==1){
					page = 2;
				}
			
				if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
					choisirTypeStylo(5,255, 99, 71);
					rectangle(240,-215,377,-247);
				}
				
				else{
					choisirTypeStylo(5,100, 100, 100);
					rectangle(240,-215,377,-247);
				}
			
			
		tamponner();}//fin de la boucle if(page==5)
		
	if(page==10){
			effacerTableau();
			
			EtatSourisClavier esc=lireEtatSourisClavier();
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210 && esc.sourisBoutonGauche==1){
				f=1;
				printf("cest fini\n");
				return EXIT_SUCCESS;
			}
			
			
			
			pj = fond(pj, p1, p2,  p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23,p24);
			
			afficherImage(gameover, 0 - tn_largeur(gameover)/2, 100 + tn_hauteur(gameover)/2);
			afficherImage(exit, 250, -220);
			afficherImage(retour, -270 - tn_largeur(retour)/2, -210 + tn_hauteur(retour)/2);
			afficherImage(restart, 0 - tn_largeur(restart)/2, -100 + tn_hauteur(restart)/2);
			
			
			if(esc.sourisX>-375 && esc.sourisX<-165 && esc.sourisY>-224 && esc.sourisY<-196){
				
				choisirTypeStylo(4, 50, 205, 50);
				rectangle(-375,-224,-165,-196);
}
			else{choisirTypeStylo(5, 100, 100, 100);
				rectangle(-375,-224,-165,-196);
				}
				
				
			if(esc.sourisX>-375 && esc.sourisX<-165 && esc.sourisY>-224 && esc.sourisY<-196 && esc.sourisBoutonGauche ==1){
				page = 0;
			}
			
				/*-------------------------------------------------------*/
			
			if(esc.sourisX>240 &&esc.sourisX<390 && esc.sourisY>-240 && esc.sourisY<-210){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(240,-215,377,-247);
				}
			else{
				choisirTypeStylo(5,100, 100, 100);
				rectangle(240,-215,377,-247);
			}
				
				/*-----------------------------------------------------------*/
			
			if(esc.sourisX>-75 && esc.sourisY<75 && esc.sourisY<-80 && esc.sourisY>-120){
				choisirTypeStylo(5,255, 99, 71);
				rectangle(-75, -120, 75, -80);
			}
			else{
				choisirTypeStylo(5, 100, 100, 100);
				rectangle(-75, -120, 75, -80);
			}
			
			if(esc.sourisX>-75 && esc.sourisY<75 && esc.sourisY<-80 && esc.sourisY>-120 && esc.sourisBoutonGauche==1){
				page = 1;
				vaisseau.x = -385;
				vaisseau.y = 0;
			}
			
			
			
			
		tamponner();}//fin de la boucle if(page==10)
	

}//fin de la grande boucle while(f==0)
	
		libererImage(vaisseaubas);
		libererImage(vaisseaudroit);
		libererImage(vaisseauhaut);
		libererImage(space);
		libererImage(fire);
		libererImage(goku);
		libererImage(p1);
		libererImage(p2);
		libererImage(p3);
		libererImage(p4);
		libererImage(p5);
		libererImage(p6);
		libererImage(p7);
		libererImage(p8);
		libererImage(p9);
		libererImage(p10);
		libererImage(p11);
		libererImage(p12);
		libererImage(p13);
		libererImage(p14);
		libererImage(p15);
		libererImage(p16);
		libererImage(p17);
		libererImage(p18);
		libererImage(p19);
		libererImage(p20);
		libererImage(p21);
		libererImage(p22);
		libererImage(p23);
		libererImage(p24);
		libererImage(titre);
		libererImage(settings);
		libererImage(start);
		libererImage(retour);
		libererImage(dif);
		libererImage(gamemode);
		libererImage(controls);
		libererImage(choix);
		libererImage(easy);
		libererImage(normal);
		libererImage(hard);
		libererImage(gameover);
		libererImage(spacebar);
		libererImage(dragon);
		libererImage(ballmode);
		libererImage(select);
		libererImage(normalmode);
		libererImage(alien);
		libererImage(freezer);
		libererImage(alyen);
		libererImage(exit);
		libererImage(zqsd);
		libererImage(touches_directions);
		libererImage(moveship);
		libererImage(use);
		libererImage(toshoot);
		libererImage(barspace);
		libererImage(restart);
}/*fin du int main()*/






								/*----------------------------------------Définitions des fonctions---------------------------------------------*/
								/*----------------------------------------Définitions des fonctions---------------------------------------------*/
								/*----------------------------------------Définitions des fonctions---------------------------------------------*/
									
									
									
									
									

								/*-------------------------------------debut de la fonction déplacement vaisseau-------------------------------------------------------*/
Objet deplacementvaisseau (EtatSourisClavier esc, int p, Objet vaisseau, Image vaisseaudroit, Image vaisseauhaut, Image vaisseaubas, int haut, int bas, int droite, int gauche){
	if(esc.touchesClavier[droite] == 1 && -245<vaisseau.y && vaisseau.y<245 && -399<vaisseau.x && vaisseau.x<399 	){
			vaisseau.x=vaisseau.x+7;
			p = 0;
			
			
		
		}
		
		 if(esc.touchesClavier[gauche] == 1 && -245<vaisseau.y && vaisseau.y<245 && -399<vaisseau.x && vaisseau.x<399 	) {
			 vaisseau.x = vaisseau.x - 7;
			 p = 0;
			
		
		}
		
		 if(esc.touchesClavier[bas]==1 && -245<vaisseau.y && vaisseau.y<245 && -399<vaisseau.x && vaisseau.x<399 	) {
			 vaisseau.y= vaisseau.y - 7;
			 p = 1;
			
			
		}
		
		 if(esc.touchesClavier[haut]==1 && -245<vaisseau.y && vaisseau.y<245 && -399<vaisseau.x && vaisseau.x<399	){
			 vaisseau.y = vaisseau.y + 7;
			 p = 2;
			
			
		}
		//la partie suivant permet au vaisseau de ne pas sortir du cadre
		
		 if(vaisseau.y ==-245 || vaisseau.y ==245|| vaisseau.x ==-399 || vaisseau.x ==399){
			
			if(vaisseau.y==-245){vaisseau.y=vaisseau.y+7;}
			
			else if(vaisseau.y==245){vaisseau.y=vaisseau.y-7;}
			else if(vaisseau.x==-399){vaisseau.x=vaisseau.x+7;}
			else if(vaisseau.x==399){vaisseau.x=vaisseau.x-7;}
			
			afficherImage(vaisseaudroit, vaisseau.x - tn_largeur(vaisseaudroit)/2, vaisseau.y + tn_hauteur(vaisseaudroit)/2);
		}
		
		if (p==0){
			afficherImage(vaisseaudroit, vaisseau.x - tn_largeur(vaisseaudroit)/2, vaisseau.y + tn_hauteur(vaisseaudroit)/2);
			
			}
			
		if (p==1){
			afficherImage(vaisseaubas, vaisseau.x - tn_largeur(vaisseaubas)/2, vaisseau.y + tn_hauteur(vaisseaubas)/2);
			p = 0;
			}
			
		if (p==2){
			afficherImage(vaisseauhaut, vaisseau.x - tn_largeur(vaisseauhaut)/2, vaisseau.y + tn_hauteur(vaisseauhaut)/2);
			p=0;
			}
		
		
		return vaisseau;
	
}


								/*-------------------------------------fin de la fonction déplacement vaisseau-------------------------------------------------------*/








								/*-------------------------------------debut de la fonction qui affiche les boules de feu------------------------------------------------*/
int afficherbdf( int i, Objet bouledefeu[], Image fire, EtatSourisClavier esc, Objet vaisseau){
	
	
		
		if (esc.touchesClavier[44]==1)
		{	
				double h = delta_temps();
				
				if(h>0.1){
				bouledefeu[i].x = vaisseau.x + 60;
				bouledefeu[i].y = vaisseau.y;
				
				i++;}
				
			
		}
		
		int k = 0;
		while(k<i)
		{ 	if(bouledefeu[k].x !=401){
				bouledefeu[k].x = bouledefeu[k].x+10;
				
				afficherImage(fire, bouledefeu[k].x - tn_largeur(fire)/2, bouledefeu[k].y + tn_hauteur(fire)/2);
				k++;}
		
		}
		
		if(i==10){i = 0;}
		return i;
	
}
									/*-------------------------------------fin de la fonction qui affiche les boules de feu------------------------------------------------*/
									
									
									
									
									
									
									
									
									
									


									/*-------------------------------------debut de la fonction qui fait apparaitres les ennemis aléatoirement en y-----------------------------*/

	int ennemis(Objet ennemi[], Image goku, int B, int niveau){
		
	int e = 0;
	while( ennemi[e].pf == 1/*!=0*/){
			e++;}
	
	int r;
	r = fmod(B, 80);
	
	
	if(r ==0 ){
		
			ennemi[e].x = 401;
			ennemi[e].y = -160+rand()%(190+1-(-160));
			ennemi[e].pf = 1;
		
	}
	
	int z=0;
	while(z<10){
		if(ennemi[z].pf == 1){
			if(ennemi[z].x > -420){
			
				ennemi[z].x = ennemi[z].x -niveau;
				afficherImage(goku, ennemi[z].x - tn_largeur(goku)/2, ennemi[z].y + tn_hauteur(goku)/2 );
				
			
			}
			else{ennemi[z].pf = 0;}
			
		}
		z++;
	}
		return niveau;
	}
										/*-------------------------------------fin de la fonction qui fait apparaitres les ennemis aléatoirement en y-----------------------------*/
	
	
	
	
	
										/*--------fonction annexe qui sert a calculer des distances----------*/
	double distance(double x1, double y1, double x2, double y2){
		
		
		double D = sqrt((x1 - x2)*(x1-x2) + (y1-y2)*(y1-y2));
		return D;
		
		
		
	}
	
	
					/*------------------------fonction du fond animé dans le menu et les parametres----------------------*/
	int fond(int pj, Image p1, Image p2, Image p3,Image p4,Image p5,Image p6,Image p7,Image p8,Image p9,Image p10,Image p11,Image p12,Image p13,Image p14,Image p15,Image p16,Image p17,Image p18,Image p19,Image p20,Image p21,Image p22,Image p23,Image p24){
	
	if(pj ==0){
			afficherImage(p1, -400, 250);
		pj++;}
			
	
		

		else if(pj ==1){
			afficherImage(p2, -400, 250);
			pj++;
		}
		
		
		else if(pj==2){
			afficherImage(p3, -400, 250);
			pj++;
			}
		
		else if(pj==3){
			afficherImage(p4, -400, 250);
			pj++;}
			
		else if(pj==4){
			afficherImage(p5,-400,250);
			pj++;}

		else if(pj==5){
			afficherImage(p6,-400, 250);
			pj++;}
			
		else if(pj==6){
			afficherImage(p7, -400, 250);
			pj++;}

		else if(pj==7){
			afficherImage(p8,-400,250);
			pj++;}

		else if(pj==8){
			afficherImage(p9,-400, 250);
			pj++;}

		else if(pj==9){
			afficherImage(p10, -400, 250);
			pj++;}
			
		else if(pj==10){
			afficherImage(p11, -400, 250);
			pj++;}
			
		else if(pj==11){
			afficherImage(p12,-400,250);
			pj++;;}
		
		 else if(pj ==12){
			afficherImage(p13, -400, 250);
		pj++;}
			
	
		
	
	
		else if(pj ==13){
			afficherImage(p14, -400, 250);
			pj++;
		}
		
		
		else if(pj==14){
			afficherImage(p15, -400, 250);
			pj++;
			}
		
		else if(pj==15){
			afficherImage(p16, -400, 250);
			pj++;}
			
		else if(pj==16){
			afficherImage(p17,-400,250);
			pj++;}

		else if(pj==17){
			afficherImage(p18,-400, 250);
			pj++;}
			
		else if(pj==18){
			afficherImage(p19, -400, 250);
			pj++;}

		else if(pj==19){
			afficherImage(p20,-400,250);
			pj++;}

		else if(pj==20){
			afficherImage(p21,-400, 250);
			pj++;}

		else if(pj==21){
			afficherImage(p22, -400, 250);
			pj++;}
			
		else if(pj==22){
			afficherImage(p23, -400, 250);
			pj++;}
			
		else if(pj==23){
			afficherImage(p24,-400,250);
			pj =0;}
			
			return pj;
	}
	
	
				/*------------------------fin de la fonction du fond animé dans le menu et les parametres----------------------*/
	
	
	
						/*-----------------------------------fonction colisions---------------------------------*/
	int collisions(Objet vaisseau,Objet bouledefeu[], Objet ennemi[], int page){
		
					int o = 0;
			while(o<10){
			
				if(ennemi[o].pf == 1){
				
					double Distance = distance(vaisseau.x, vaisseau.y, ennemi[o].x, ennemi[o].y);
					if(Distance<60){
					
					vaisseau.x = -400;
					vaisseau.y = 0;
					page = 10;//on affiche la page "GAME OVER" si un ennemi percute notre vaisseau
					
					
				}
				
				
			}
			o++;
			
		}
	
		
		int w = 0;
		
		while(w<10){
			int v = 0;
			
			while(v<10){
				
				if(ennemi[v].pf == 1){
					
					double DT = distance(ennemi[v].x , ennemi[v].y, bouledefeu[w].x, bouledefeu[w].y);
					if (DT<50){
						bouledefeu[w].x = 500;
						ennemi[v].pf = 0;
						printf("boum\n");
						
					}
				}
				v++;
			}
			
			w++;
			
		}
		return page;
	}
				/*-----------------------------------fin de la fonction colisions---------------------------------*/
	
	
	/*------------------------------------------fonction tracage rectangle sans fond--------------------------------*/
	void rectangle(int x1, int y1, int x2, int y2){
		
		tracerSegment(x1,y1,x2, y1);
		tracerSegment(x2, y1, x2, y2);
		tracerSegment(x2, y2,x1, y2);
		tracerSegment(x1, y2, x1, y1);
		
	}
	
	
	
	
	
	/*-----------------------------------fonction qui affiche des segments qui reculent dans le jeu(augmente la sensation de mouvement dans le jeu)----------------------------*/
	Objet planbouge(Objet mouvement){
			choisirTypeStylo(5, 152, 255, 152);
		if(mouvement.bouge+350>-400){
			
			tracerSegment(mouvement.bouge,220,mouvement.bouge+350,220);
			tracerSegment(mouvement.bouge,-180,mouvement.bouge+350,-180);
			
			mouvement.bouge = mouvement.bouge -7;
		}
		else{
			mouvement.bouge=400;
		}
		if(mouvement.abc+300>-400){
			
			tracerSegment(mouvement.abc,230,mouvement.abc+350,230);
			tracerSegment(mouvement.abc,-190,mouvement.abc+350,-190);
			mouvement.abc = mouvement.abc -7;
		}
		else{
			mouvement.abc = 600;
		}
		return mouvement;
	}
	
	
				/*----------------fonction qui donne limpresion de se deplacer dans lespace(meme image en 2 fois qui se suivent-----------------*/
				//les images space et space1 sont exactement les mémes, pendant que l'une avance de droite à gauche l'autre fais la meme chose mais ne part pas du même point de départ
	Objet bougerplan(Objet planquibouge, Image space, Image space1){
			if(planquibouge.az>-1200){
				afficherImage(space, planquibouge.az, 250);
				planquibouge.az = planquibouge.az - 2;
			}
			else{
				planquibouge.az = 390;
			}
			
			if(planquibouge.za>-1200){
				afficherImage(space1, planquibouge.za, 250);
				planquibouge.za = planquibouge.za - 2;
			}
			else{
				planquibouge.za = 390;
			}
			return planquibouge;
	}
	
	
	
	